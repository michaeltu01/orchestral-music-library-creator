# Princess Anne High School Orchestras Music Library Editor
*Version 1.1*

Welcome to the PAHS Orchestras Music Library Editor! You can fork/clone the repo OR download the "CS IA [version number].zip" folder containing the latest JAR executable.

**WARNING:** Do NOT edit the "Database.xlsx" file as that is the database for the application!

# Version Changes

## 1.2 (IA FINAL)
* Minor bug fixes

## 1.1
* Minor bug fixes